# Mythic Duel — Cards v0

# Deck A: Red Baobab

Identity: Hunter / Spirit / Memory / evolution midrange.

## Red Baobab Shrines

### Shrine of the Red Baobab
- Shrine
- Vitality 10
- The first time each turn one of your Beings dies, gain 1 Memory.

### Hunter’s Root-Stone
- Shrine
- Vitality 10
- Your Hunters get +1 Attack while attacking Shrines.

### Moonlit Roots
- Shrine
- Vitality 10
- At the end of your turn, if you did not attack a Shrine this turn, restore 1 Vitality to a Shrine.

## Red Baobab Ancestors

### First Hunter
- Ancestor — Hunt
- Awaken condition: One of your Beings destroyed an enemy this turn.
- Awaken cost: 2 Memory.
- While Awakened: Your Beings get +1 Attack while attacking Shrines.

### Grandmother Beneath the Roots
- Ancestor — Root, Moon
- Awaken condition: You restored a Shrine this turn or skipped Shrine attacks last turn.
- Awaken cost: 2 Memory.
- While Awakened: At the end of your turn, restore 1 Vitality to your most damaged Shrine.

### Child Who Remembered the Dead
- Ancestor — Memory, Spirit
- Awaken condition: A Spirit Dispersed since your last turn.
- Awaken cost: 2 Memory.
- While Awakened: The first time each turn you gain Memory, draw 1 then discard 1.

## Red Baobab Main Deck — 30 cards

### 3x Young Hunter
- Being — Hunter
- Cost 1 Offering
- Attack 2 / Vitality 1

### 3x River Hunter
- Being — Hunter
- Cost 2 Offerings
- Attack 3 / Vitality 2
- When this destroys an enemy, gain 1 Memory.

### 2x Baobab Guardian
- Being — Guardian
- Cost 3 Offerings
- Attack 2 / Vitality 4
- Guard
- When this survives combat, restore 1 Vitality to a Shrine.

### 2x Pale River Spirit
- Spirit
- Cost 2 Offerings
- Attack 2 / Vitality 2
- Disperse
- When this Disperses, gain 1 additional Memory.

### 2x Deep River Spirit
- Spirit
- Cost 4 Offerings + 1 Memory
- Attack 3 / Vitality 5
- Disperse
- When this Disperses, restore 2 Vitality to a Shrine.

### 2x Esprit du Léopard
- Spirit — Possession
- Cost 2 Offerings + 1 Memory
- Attach to a Being.
- Attached Being gets +2 Attack and Ambush.
- When the host dies or this Possession is displaced, Disperse.

### 3x Ritual of Red Moon
- Rite
- Fade
- Cost 2 Offerings
- Deal 2 damage to a Being.
- If it dies this turn, gain 1 Memory.
- After resolving, move this card to Forgotten.

### 2x Offering of Milk and Ash
- Rite
- Fade
- Cost 1 Offering
- Restore 3 Vitality to a Shrine.
- If you attacked a Shrine this turn, this costs +1 Memory.
- After resolving, move this card to Forgotten.

### 2x Spear of First Dawn
- Relic
- Cost 2 Offerings
- Attach to a Being.
- Attached Being gets +1 Attack.
- If attached Being is a Hunter attacking a Shrine, it gets +2 Attack instead.

### 2x Hunter’s Call
- Prepared Tactic
- Fade
- Cost 1 Offering
- Trigger: A Hunter you control attacks.
- Effect: It gets +1 Attack this combat. If it destroys an enemy, gain 1 Memory.
- After triggering/resolving, move this card to Forgotten.
- If it expires without triggering, move it to Forgotten.

### 2x Root-Woven Guard
- Prepared Tactic
- Fade
- Cost 1 Offering + 1 Memory
- Trigger: A Shrine you control would take attack damage.
- Effect: Reduce that damage by 3.
- After triggering/resolving, move this card to Forgotten.
- If it expires without triggering, move it to Forgotten.

### 2x Leopard Hunter
- Being — Hunter, Leopard, L2
- Cost 5 Offerings
- Attack 4 / Vitality 4
- Ambush
- WeaponMaster
- SoulSlayer
- Evolve from: Hunter
- Condition: That Hunter destroyed an enemy this turn.
- Evolve cost: 3 Offerings.
- When this evolves, ready it.
- WeaponMaster: This unit has Pierce while it has a Relic attached.
- SoulSlayer: This unit has Pierce while it has a Possession attached.

### 1x Kuma Who Wounded the Sun
- Being — Hunter, Sun, L3
- Cost 8 Offerings + 2 Memory
- Attack 6 / Vitality 6
- Pierce
- Evolve from: Leopard Hunter
- Condition: This Being damaged a Shrine this turn.
- Evolve cost: 4 Offerings + 2 Memory.
- When this evolves, deal 3 damage to another Shrine.

# Deck B: Iron Hyena

Identity: regular Being pressure / Shrine aggression / anti-Spirit / anti-evolution.

## Iron Hyena Shrines

### Iron Hyena Den
- Shrine
- Vitality 10
- The first time each turn one of your Beings attacks a Shrine, gain 1 Memory.

### Bone-Fang Shrine
- Shrine
- Vitality 10
- Your Beings get +1 Attack while attacking damaged Shrines.

### Rusted Moon Shrine
- Shrine
- Vitality 10
- Whenever an enemy Spirit Disperses, deal 1 damage to an enemy Shrine.

## Iron Hyena Ancestors

### Ancestor of the Iron Hyena
- Ancestor — Iron, Hyena
- Awaken condition: You damaged an enemy Shrine this turn.
- Awaken cost: 2 Memory.
- While Awakened: The first time each turn one of your Beings attacks a Shrine, deal 1 damage to another enemy Shrine.

### Tooth-Mother of the Dry Earth
- Ancestor — Hyena, Earth
- Awaken condition: One of your Beings survived combat this turn.
- Awaken cost: 2 Memory.
- While Awakened: Your Wounded Beings get +1 Attack.

### Smith of Black Teeth
- Ancestor — Iron
- Awaken condition: You played a Relic this turn.
- Awaken cost: 2 Memory.
- While Awakened: Your Relics cost 1 less Offering.

## Iron Hyena Main Deck — 30 cards

### 4x Bone-Cracker Cub
- Being — Hyena, Pack
- Cost 1 Offering
- Attack 2 / Vitality 1
- Pack
- Gets +1 Attack while attacking damaged Shrines.

### 3x Iron Hyena Raider
- Being — Hyena, Pack
- Cost 2 Offerings
- Attack 3 / Vitality 2
- Pack
- When this attacks a Shrine, deal 1 damage to another Shrine controlled by the same player.

### 3x Black-Tooth Smith
- Being — Smith
- Cost 3 Offerings
- Attack 2 / Vitality 3
- When this enters, you may attach a Relic from your hand to a Being. It costs 1 less Offering.

### 1x Iron Guard
- Being
- Cost 2 Offerings
- Attack 2 / Vitality 3
- Guard

### 1x Rust Hyena Spirit
- Spirit
- Cost 2 Offerings
- Attack 2 / Vitality 2
- Disperse
- When this Disperses, deal 1 damage to a Shrine.

### 3x Bite the Roots
- Rite
- Fade
- Cost 2 Offerings
- Deal 3 damage to a Shrine.
- If that Shrine breaks this turn, gain 1 Memory.
- After resolving, move this card to Forgotten.

### 2x Iron Snare
- Prepared Tactic
- Fade
- Cost 1 Offering
- Trigger: The next enemy unit with 3 or more Attack attacks.
- Effect: That unit gets -2 Attack this combat. If it is Possessed, its Possession Disperses.
- After triggering/resolving, move this card to Forgotten.
- If it expires without triggering, move it to Forgotten.

### 1x False Opening
- Prepared Tactic
- Fade
- Cost 1 Offering + 1 Memory
- Trigger: An enemy Being evolves.
- Effect: Deal 3 damage to that Being.
- After triggering/resolving, move this card to Forgotten.
- If it expires without triggering, move it to Forgotten.

### 2x Fang Relic
- Relic
- Cost 2 Offerings
- Attach to a Being.
- Attached Being gets +1 Attack.
- When attached Being attacks a damaged Shrine, gain 1 Memory.

### 2x Bone Spear
- Relic
- Cost 1 Offering
- Attach to a Being.
- Attached Being gets +1 Attack.
- If attached Being attacks a damaged Shrine, it has Pierce.

### 2x Hyena Pack Call
- Rite
- Fade
- Cost 2 Offerings
- Summon two 1/1 Hyena Beings.
- After resolving, move this card to Forgotten.

### 2x Iron Hyena Champion
- Being — Hyena, Iron, L2, Pack
- Cost 5 Offerings
- Attack 5 / Vitality 3
- Pack
- Evolve from: Hyena
- Condition: That Hyena damaged a Shrine this turn.
- Evolve cost: 3 Offerings.
- When this evolves, deal 2 damage to the same Shrine.

### 2x Pack Harrier
- Being — Hyena, Pack
- Cost 1 Offering
- Attack 1 / Vitality 1
- Pack
- When this attacks a Shrine and is blocked, deal 1 damage to the attacked Shrine.

### 2x Blood-Scent Hyena
- Being — Hyena, Pack
- Cost 2 Offerings
- Attack 2 / Vitality 2
- Pack
- When this attacks a damaged Shrine, deal 1 damage to another enemy Shrine.
